//Preloader
$(document).ready(() => {
    //$(document).ready() has no equivalent in vanilla javascript
    document.getElementById("preloader").remove();
})
